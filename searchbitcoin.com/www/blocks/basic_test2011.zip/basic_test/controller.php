<?php
	class BasicTestBlockController extends BlockController {
		
		var $pobj;
		
		protected $btDescription = "A simple testing block for developers.";
		protected $btName = "Basic Test";
		protected $btTable = 'btBasicTest';
		protected $btInterfaceWidth = "350";
		protected $btInterfaceHeight = "300";
		
		
	}
	
?>