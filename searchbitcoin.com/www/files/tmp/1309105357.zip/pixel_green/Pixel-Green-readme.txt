Concrete5 Pixel Green Theme
by Weblicating.com

Converted from a template by Erwin Aligam
http://www.styleshout.com/templates/preview/PixelGreen13/

Pixel Green will install automatically as a package from the Concrete5 Marketplace and can be added from Dashboard - Add Functionality, once that is done you need to activate it from Dashboard- Pages and Themes

If you downloaded the file you can copy all the files in the archive (the pixel_green directory) to your packages directory then install from Dashboard - Add Functionality and then activating the theme from Dashboard- Pages and Themes.

You can also install manually to your themes directory by copying the themes/pixel_green directory to the themes directory of your Concrete5 installation.

Once installed and activated your site will display the Pixel Green Theme.  If you had loaded the sample content when you installed Concrete5 you will see the Main and Sidebar content on the home page.  This Central Area is fluid and the background will automatically scale depending on the amount of content in the Main area. Each Sidebar element will be wrapped with a background.

The logo on the top left is themes/images/logo.png You can change this image for your own logo. If this file is deleted the Site Name as defined in the Dashboard will be displayed. You can also add an Image Block to the Scrapbook named 'logo' to change the logo on pages of your site or create File/Image Page Attributes 'logo' to replace the logo from page to page.

The Slogan beneath the Logo can be a Text Page Attribute with the handle �slogan� and will change for any page that has the attribute set.  A Scrapbook Block named �Slogan� can be created to add the slogan to all pages.  If neither an Attribute or Scrapbook block exist any block can be added to the Slogan Area.

The menu is a standard Auto Nav block using the 'Header Menu' template that comes with Concrete5.

Styling is included for menus in sidebars.

There are 5 page types included in the theme. default.php which is the right sidebar page, left_sidebar.php the left sidebar page, full.php the full width page, blog_entry.php for use with blogging functions and view.php which is used to wrap single pages.

This theme has been tested in Windows, IE7, 8 and 9, Firefox 3.6, Chrome 7 and Safari 5. On Mac Safari 5, Firefox, Chrome

Visit weblicating.com/c5themes/technologie for more info.


