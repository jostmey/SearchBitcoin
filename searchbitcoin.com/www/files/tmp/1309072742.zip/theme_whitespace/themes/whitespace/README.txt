Whitespace Concrete5 Theme

Original WordPress Theme by Brian Gardner, converted to Concrete5 by c5mix.com

This Theme is under GPL License. (http://www.opensource.org/licenses/gpl-license.php)

INSTALL: 
1. Unpack this archive in your themes/ directory.
2. Go to Dashboard and select Themes.
3. Click Install next to Whitespace theme.
4. Return to Themes page and click Activate next to Whitespace theme.

Questions, bugs and others can be emailed to hello@c5mix.com.

Original Theme Author:
Brian Gardner
bmg1227@hotmail.com
http://www.briangardner.com
http://www.briangardner.com/themes/whitespace-wordpress-theme.htm