<?php  
defined('C5_EXECUTE') or die(_("Access Denied."));
$formController = $controller;
include($this->getBlockPath() .'/form.php');
?>

