<?php    defined('C5_EXECUTE') or die(_("Access Denied.")); ?>
	<div id="footer">
		<p>Copyright (c) <?php   echo date('Y')?> <a href="<?php   echo DIR_REL?>/"><?php   echo SITE?></a> All rights reserved. Design by <a href="http://www.freecsstemplates.org/">Free CSS Templates</a>.</p>
</div>

</div>

<?php    Loader::element('footer_required'); ?>

</body>
</html>