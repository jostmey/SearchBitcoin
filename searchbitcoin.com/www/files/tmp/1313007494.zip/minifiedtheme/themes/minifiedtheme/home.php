<?php  
defined('C5_EXECUTE') or die(_("Access Denied."));
$this->inc('elements/header.php'); ?>

<div id="slideshow">
		<?php   $a = new Area('Slideshow'); $a->display($c); ?>
		<div id="text-placeholder">
			<div class="inner-text">
			<?php   $a = new Area('SplashText'); $a->display($c); ?>
			</div>
		</div>
</div>

<div id="home-center">
<div class="home-left">
	<?php   $a = new Area('ContentBlock-1'); $a->display($c); ?>
</div>

<div class="home-box box-1">
	<?php   $a = new Area('ContentBlock-2'); $a->display($c); ?>
</div>
<div class="home-box box-2">
	<?php   $a = new Area('ContentBlock-3'); $a->display($c); ?>
</div>
<div class="home-box box-3">
	<?php   $a = new Area('ContentBlock-4'); $a->display($c); ?>
</div>
<br style="clear: both;" />
</div>
<br style="clear: both;" />
<div id="home-bottom">

<div class="home-left">
	<?php   $a = new Area('ContentBlock-5'); $a->display($c); ?>
</div>

	<div id="home-text-right">
		<?php   $a = new Area('ContentBlock-6'); $a->display($c); ?>
	</div>
</div>
<br style="clear: both;" /><br />
<?php  $this->inc('elements/footer.php'); ?>