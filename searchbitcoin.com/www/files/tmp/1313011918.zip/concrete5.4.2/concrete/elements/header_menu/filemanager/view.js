$(function() {
	$("#ccm-page-edit-nav-filemanager").dialog();
});