$(function() {
	$("#ccm-page-edit-nav-sitemap").dialog();
});