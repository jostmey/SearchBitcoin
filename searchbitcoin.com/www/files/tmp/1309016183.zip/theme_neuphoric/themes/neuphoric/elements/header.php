<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<!-- This template can be downloaded from www.openwebdesign.org. Just search for neuphoric -->
<!-- This template has been modified by mejobloggs (http://www.openwebdesign.org/userinfo.phtml?user=mejobloggs) -->
<!-- Please use this template according to the license on the original template (included as pleaseread.txt) -->
<!-- The original of this template was designed by http://www.tristarwebdesign.co.uk - please visit for more templates & information - thank you. -->

<head>
	<title>C5 Theme</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" type="text/css" href="<?php  echo $this->getThemePath()?>/styles.css" media="screen"/>
	<link rel="stylesheet" type="text/css" href="<?php  echo $this->getThemePath()?>/typography.css" media="screen"/>
	<?php   Loader::element('header_required'); ?>
</head>