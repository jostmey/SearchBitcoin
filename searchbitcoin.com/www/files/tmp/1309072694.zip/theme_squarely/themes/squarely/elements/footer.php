<?php  defined('C5_EXECUTE') or die(_("Access Denied.")); ?>

<div id="footer">
	<p id="legal">Template by <a href="http://www.dev-farm.com">Dev-Farm.com</a> using <a href="http://www.freecsstemplates.org/">Free CSS Templates</a></p>
</div>


<?php  Loader::element('footer_required'); ?>

</body>
</html>