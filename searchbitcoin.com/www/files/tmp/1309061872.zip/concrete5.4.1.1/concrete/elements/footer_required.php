<?php 
 
echo Config::get('SITE_TRACKING_CODE');

?>