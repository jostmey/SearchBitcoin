<?php 
defined('C5_EXECUTE') or die("Access Denied.");

if($blockStyle && $blockStyle->getCustomStyleRuleID() ){ ?></div><?php  } ?>