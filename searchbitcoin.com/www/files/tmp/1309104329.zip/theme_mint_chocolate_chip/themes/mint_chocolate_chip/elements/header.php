<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Mint Chocolate Chip</title>
<meta name="description" content="Mint Chocolate Chip is a clean, tableless, minty design. For more information please visit my website, http://www.andrewstrojny.com "/>
<style type="text/css">@import "<?php  echo $this->getStyleSheet('style.css')?>";</style>
<style type="text/css">@import "<?php  echo $this->getStyleSheet('typography.css')?>";</style>
<?php echo Loader::element('header_required');?>
</head>

<body>

<div id="wrapper"> 

	<div id="header">
		<div id="header-bkg">
			<div id="header-content">
				<h1><?php   echo SITE?></h1>
				<p><?php  $a = new Area('Tagline'); $a->display($c); ?></p>
			</div>
		</div>
	</div>

