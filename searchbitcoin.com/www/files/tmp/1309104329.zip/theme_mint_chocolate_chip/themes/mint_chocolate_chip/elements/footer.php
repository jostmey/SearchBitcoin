
	<div id="footer">

		<img src="<?php echo View::getThemePath()?>/images/footer.png" width="770" height="32" alt="Footer"/>



		<!--	Do not remove the link to wSidebarww.andrewstrojny.com below. It is the only thing I ask of you if you choose to use my design.
			Feel free to add a 'Modified by [Your Name]' - or similar - link next to it if you have made changes to the layout.
			Feel free to get more information or ask me questions on www.andrewstrojny.com.
			
			(c) Andrew Strojny: 2006 -->

			<p>&copy; 2006 yourname | design by <a href="http://www.andrewstrojny.com">andrewstrojny</a></p>
			<p>This site is powered by <a href="www.concrete5.org">concrete5</a>.</p>

	</div>

</div>

<?php echo Loader::element('footer_required');?>

</body>
</html>
