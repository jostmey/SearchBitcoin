<?php  defined('C5_EXECUTE') or die(_("Access Denied.")); ?>

	<div id="footer">
		<p id="legal">CSS by <a href="http://www.freecsstemplates.org/">Free CSS Templates</a>.</p>
		<p id="links">C5 Theme by <a href="http://www.dev-farm.com">Dev-Farm.com</a></p>
	</div>

<?php  Loader::element('footer_required'); ?>

</body>
</html>