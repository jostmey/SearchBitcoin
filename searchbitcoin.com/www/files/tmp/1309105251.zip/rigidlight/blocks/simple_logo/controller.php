<?php 
	class SimpleLogoBlockController extends BlockController {
		
		var $pobj;
		
		protected $btDescription = "Add a Logo to 'Rigid' Themes";
		protected $btName = "Simple Logo";
		protected $btTable = 'btSimpleLogo';
		protected $btInterfaceWidth = "370";
		protected $btInterfaceHeight = "350";
		
		
	}
	
?>