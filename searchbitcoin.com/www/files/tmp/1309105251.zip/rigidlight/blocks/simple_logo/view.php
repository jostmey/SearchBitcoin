<span class="largeWhite"><?php  echo $logoTitleWhite ?></span>
                <span class="largeYellow"><?php  echo $logoTitleYellow ?></span>
                <span class="logoSubtitle"><?php  echo $logoSubTitle ?></span>