
<div style="margin: 20px 0;">
<?php  echo $form->label('logoTitleWhite', 'Logo/Site Title in big White:');?>
<?php  echo $form->text('logoTitleWhite', $logoTitleWhite, array('style' => 'width: 320px'));?>
</div>

<div style="margin: 20px 0;">
<?php  echo $form->label('logoTitleYellow', 'Logo/Site Title in big Yellow:');?>
<?php  echo $form->text('logoTitleYellow', $logoTitleYellow, array('style' => 'width: 320px'));?>
</div>

<div style="margin: 20px 0;">
<?php  echo $form->label('logoSubTitle', 'Logo/Site Sub-Title:');?>
<?php  echo $form->text('logoSubTitle', $logoSubTitle, array('style' => 'width: 320px'));?>
</div>
