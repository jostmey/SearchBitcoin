<?php  echo $form->label('compName', 'Company Name');?>
<?php  echo $form->text('compName', array('style' => 'width: 320px'));?>

<?php  echo $form->label('stAddress', 'Street Address');?>
<?php  echo $form->text('stAddress', array('style' => 'width: 320px'));?>

<?php  echo $form->label('stAddress2', 'Street Address 2');?>
<?php  echo $form->text('stAddress2', array('style' => 'width: 320px'));?>

<?php  echo $form->label('city', 'City');?>
<?php  echo $form->text('city', array('style' => 'width: 320px'));?>

<?php  echo $form->label('state', 'State');?>
<?php  echo $form->text('state', array('style' => 'width: 320px'));?>

<?php  echo $form->label('zipCode', 'Zip');?>
<?php  echo $form->text('zipCode', array('style' => 'width: 320px'));?>

<?php  echo $form->label('phNumber', 'Phone Number');?>
<?php  echo $form->text('phNumber', array('style' => 'width: 320px'));?>