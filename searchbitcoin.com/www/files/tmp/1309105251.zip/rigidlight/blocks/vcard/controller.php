<?php 
	class VcardBlockController extends BlockController {
		
		var $pobj;
		
		protected $btDescription = "A simple block to add vCard styled addresses.";
		protected $btName = "vCard Address";
		protected $btTable = 'btvCard';
		protected $btInterfaceWidth = "370";
		protected $btInterfaceHeight = "350";
		
		
	}
	
?>