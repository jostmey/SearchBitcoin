<div class="vcard">
        	
            <span class="fn org"><?php  echo $compName?></span>&nbsp;
        	<span class="adr">
                <span class="street-address"><?php  echo $stAddress?></span>
                <span class="street-address"><?php  echo $stAddress2?></span>&nbsp; | &nbsp;
                <span class="locality"><?php  echo $city?>, </span>
                <span class="region"><?php  echo $state?></span>
                <span class="postal-code"><?php  echo $zipCode?></span>&nbsp; | &nbsp;
            </span>
            <span class="tel">
            	<span class="type">Phone:</span>
                <span class="value"><?php  echo $phNumber?></span>
            </span>
        
        </div><!-- .vcard -->
