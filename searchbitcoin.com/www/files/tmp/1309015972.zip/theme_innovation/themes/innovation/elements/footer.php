<?php  defined('C5_EXECUTE') or die(_("Access Denied.")); ?>

<div style="float:left;">&nbsp;</div>

<div id="footer">

	<span class="powered-by">Template by <a href="http://www.dev-farm.com">Dev-Farm.com</a> using <a href="http://www.freecsstemplates.org/">Free CSS Templates</a></span>

</div>

<?php  Loader::element('footer_required'); ?>

</div>

</body>
</html>